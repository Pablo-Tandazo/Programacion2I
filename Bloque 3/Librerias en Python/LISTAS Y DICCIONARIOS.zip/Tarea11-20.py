# 11 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 12 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 13 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 14 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 15 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 16 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 17 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 18 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 19 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")

# 20 Ingreso de palabras desde el usuario
palabras = input("Ingresa varias palabras separadas por espacios: ").split()

palabra_mas_larga = max(palabras, key=len)

print(f"La palabra más larga es: {palabra_mas_larga}")