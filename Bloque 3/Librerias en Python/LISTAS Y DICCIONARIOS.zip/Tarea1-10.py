# Ejercicio 1: crear una lista e imprimir cada elemento con su índice
elementos = ["manzana", "banana", "cereza", "naranja", "kiwi"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
# Ejercicio 2: crear una lista e imprimir cada elemento con su índice
elementos = ["Pablo", "Pedro", "Juan", "Luis", "Mario"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 3: crear una lista e imprimir cada elemento con su índice
elementos = ["Moto", "Bus", "Tren", "Avion", "Auto"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 4: crear una lista e imprimir cada elemento con su índice
elementos = ["Perro", "Gato", "Vaca", "Caballo"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 5: crear una lista e imprimir cada elemento con su índice
elementos = ["1", "2", "3", "4", "5"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 6: crear una lista e imprimir cada elemento con su índice
elementos = ["Python", "Java", "c++", "ruby", "go"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 7: crear una lista e imprimir cada elemento con su índice
elementos = ["10", "20", "30", "40", "50"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
    # Ejercicio 8: crear una lista e imprimir cada elemento con su índice
elementos = ["Movistar", "Huawei", "Tecno", "Motorola", "LG"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
     # Ejercicio 9: crear una lista e imprimir cada elemento con su índice
elementos = ["Movistar", "CLaro", "CNT", "tuenti", "DirecTv"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")
     # Ejercicio 10: crear una lista e imprimir cada elemento con su índice
elementos = ["Oso", "Leon", "Tigre", "Gorila", "Serpiente"]

for indice, valor in enumerate(elementos):
    print(f"Índice {indice}: {valor}")

    